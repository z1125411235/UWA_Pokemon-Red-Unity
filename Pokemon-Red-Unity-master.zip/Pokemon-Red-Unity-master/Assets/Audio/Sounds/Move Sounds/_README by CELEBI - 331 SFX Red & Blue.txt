-.-. . .-.. . -... .. 

Hey you read me!  Ripped and cleaned up by Celebi.  

Any sounds that have "1" or "2" or anything after their original name are extra or split parts of an single or multi-turn attack. 

If a sound has "direct" or a "D"after its name, that means I was unsure if the created sound from combining all the parts of the sound, sounded the same to the direct version. (So its there for comparison)  There some extras here and there.

The only pain in the neck sound was amnesia/confusion/mimic. The music ingame would change the tone of these sounds depending on the last note played.  

-.-. . .-.. . -... .. 
 _____      _      _     _ 
/  __ \    | |    | |   (_)
| /  \/ ___| | ___| |__  _ 
| |    / _ \ |/ _ \ '_ \| |
| \__/\  __/ |  __/ |_) | |
 \____/\___|_|\___|_.__/|_|

Celebi: http://cutstuff.net/forum/index.php?action=profile;area=summary;u=754

--MetaData Tags added on 7/30/2018 - 331 WAV files

For more Pokemon and videogame sound effects and audio tracks, go to:
https://downloads.khinsider.com/game-soundtracks/browse/P
https://www.sounds-resource.com
https://reliccastle.com/resources/categories/3/
https://www.deviantart.com/melodycrystel/art/Several-Pokemon-Soundfonts-485542745