﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Trainer : MonoBehaviour
{
    public System.Tuple<string,int>[] party;
    public DialogueMessage[] dialogue, defeatTrainerDialogue;
    public bool isDefeated;

}
