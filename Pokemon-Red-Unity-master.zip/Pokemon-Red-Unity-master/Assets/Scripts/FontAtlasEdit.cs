﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FontAtlasEdit : MonoBehaviour
{
    public FontAtlas fontAtlas;
}